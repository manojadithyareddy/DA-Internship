## 1. Why did you choose the Pearson correlation coefficient instead of other statistical methods?

- It effectively measures the linear relationship between the continuous variables of Discount and Profit.
- Since our primary concern was the strength and direction of the impact, Pearson provided a clear metric (-0.22).
- We also checked for outliers that might skew the result using a box plot before running the correlation.

## 2. How did you handle the 10,000 rows of data in Python to ensure the RFM analysis was accurate?

- I used the pandas .groupby() function on CustomerID to aggregate the latest date, count of orders, and sum of sales.
- I handled missing OrderIDs by dropping rows where the unique identifier was null (less than 1% of data).
- I used the .qcut() method to create quintiles for Recency, Frequency, and Monetary values.

## 3. What happens to the profit forecast if there is a sudden spike in shipping fuel costs?

- The current time-series model uses historical patterns, so a sudden external shock wouldn't be captured immediately.
- However, the 95% confidence interval provides a 'worst-case' boundary that accounts for some volatility.
- I would recommend adding a 'Shipping Cost' variable to a multivariate regression model for more sensitivity to external costs.

## 4. Why is the Furniture category specifically struggling with profitability?

- The dataset shows that Furniture has the highest 'Shipping Cost Ratio' due to weight and dimensions.
- High discounts on high-ticket, high-shipping items create a 'double-hit' on the margin.
- Unlike Office Supplies, Furniture lacks the repeat purchase frequency to justify loss-leader pricing.

## 5. In your SQL audit, what did you find regarding delivery delays?

- Standard Class shipping had an average delay of 5 days, while First Class was roughly 2 days.
- Interestingly, 15% of First Class orders experienced delays, making the premium cost a source of customer dissatisfaction and margin loss.
- I recommended a shipping audit for specific carriers in the Central region.

## 6. How would you explain the 'Net Profit Margin %' KPI to a non-technical manager?

- It represents the cents of profit we keep for every dollar of sale after all costs are paid.
- I would explain that a 12% drop means we are working just as hard but keeping significantly less of our revenue.
- It's a more important health metric than 'Total Sales' because it accounts for our spending efficiency.