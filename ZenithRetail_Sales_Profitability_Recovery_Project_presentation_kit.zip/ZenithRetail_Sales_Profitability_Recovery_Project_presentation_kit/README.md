# ZenithRetail Sales & Profitability Recovery Project

Automated analysis and dashboarding to identify profit-draining product categories and shipping inefficiencies.

## Project Overview
ZenithRetail experienced a 12% decline in profit margins despite consistent top-line revenue. This project identifies 'profit-drainers' by analyzing the intersection of discount strategies, shipping speeds, and regional logistics costs. Using the Kaggle Superstore dataset (10,000+ records), the technical objective was to isolate the variables directly impacting bottom-line erosion.

## Features
- **Regional Performance Attribution**: SQL window functions to rank regions by Return on Sales (ROS).
- **RFM Customer Segmentation**: Python-based Recency, Frequency, and Monetary scoring to classify 'VIP' vs 'At-Risk' customers.
- **Discount Sensitivity Analysis**: Statistical correlation between discount depth (>30%) and net losses.
- **Shipping Efficiency Audit**: Quantification of delivery delays and costs per shipping mode.
- **Predictive Forecasting**: 90-day profit projections using the Power BI Smart Narrative engine.

## Tech Stack
- **Database**: PostgreSQL 15 (Data warehousing and complex aggregations)
- **Programming**: Python 3.10 (Pandas, Seaborn, Matplotlib, Scikit-learn)
- **BI Tools**: Power BI Service (DAX, Power Query, AI Visuals)
- **Environment**: Jupyter Lab

## Architecture
See /docs/architecture.png for the data flow from CSV ingestion to Power BI reporting.

## Folder Structure
```text
zenith-retail-recovery/
├── data/
│   ├── raw/                  # Original Kaggle CSV
│   └── processed/            # Cleaned data for BI
├── notebooks/
│   ├── 01_eda.ipynb          # Distribution and outlier analysis
│   └── 02_rfm.ipynb          # Customer segmentation logic
├── sql/
│   ├── ddl.sql               # Schema definitions
│   └── aggregations.sql      # Profitability queries
├── reports/
│   └── zenith_dashboard.pbix # Power BI artifact
└── README.md
```

## Installation
1. Clone the repository:
```bash
git clone https://github.com/intern/zenith-retail-recovery.git
```
2. Set up the Python environment:
```bash
pip install pandas seaborn matplotlib sqlalchemy psycopg2-binary
```
3. Initialize the database:
```bash
psql -U postgres -d zenit_db -f sql/ddl.sql
```

## Usage
1. Run the SQL scripts in the `sql/` directory to generate view tables.
2. Execute the RFM notebook to generate customer segment CSVs.
3. Open `zenith_dashboard.pbix` and refresh data connections to view the Profitability Forecaster.

## Future Improvements
- Implement an automated ETL pipeline using Apache Airflow.
- Integrate an XGBoost regression model for precise margin prediction.
- Expand analysis to include supplier-side cost fluctuations.

## Author
Data Analytics Intern - ZenithRetail Project Team