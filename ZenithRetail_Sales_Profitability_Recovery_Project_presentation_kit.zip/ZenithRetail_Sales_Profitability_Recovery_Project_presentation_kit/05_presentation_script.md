## Slide 1 — Title and Project Context
Hello, I am here to present the ZenithRetail Sales and Profitability Recovery plan. Over the last quarter, we faced a 12% decline in net profit margins despite having a stable traffic flow, which indicated an internal efficiency issue rather than a lack of customer interest. My task was to dive into 10,000 order records from our global marketplace to pinpoint where we were losing money. I specifically looked at how aggressive discounting and shipping logistics were eating into our bottom line. 

**Pause & engage:** Ask the audience if they have ever noticed a major retailer offering a discount that seemed too good to be true from a business perspective.

## Slide 2 — The Problem Statement
The core problem at ZenithRetail is what I call 'profit-drainers'—high-volume transactions that actually result in negative net margins. We hypothesized that high-discount campaigns, intended to clear inventory, were actually hurting us when combined with expensive shipping modes like First Class. The goal of this analysis was to identify the exact correlation between discount depth, shipping speed, and net margin across our product categories. By quantifying these relationships, we can move away from reactive discounting and toward a data-driven pricing strategy.

**Pause & engage:** Point to a specific KPI on the slide, like the 12% margin drop, to emphasize the urgency.

## Slide 3 — Data Engineering and SQL Extraction
To build my dataset, I utilized SQL to perform heavy-duty aggregations on the Kaggle Superstore dataset. I wrote a series of queries to calculate total sales and profit margins per category, but the real insights came from high-discount impact analysis. I used SQL window functions to rank regions by their average profit margin, which allowed me to isolate geographic outliers. I also calculated the delivery delay performance by subtracting OrderDate from ShipDate to see if premium shipping costs were justified by speed.

**Pause & engage:** Explain that the RANK() window function was crucial for identifying that the Central region was underperforming despite high volume.

## Slide 4 — Exploratory Data Analysis with Python
Once the data was structured, I moved into a Jupyter Notebook using pandas and seaborn for exploratory data analysis. The scatter plots immediately revealed a non-linear relationship: profits stayed stable until discounts hit the 20% mark, after which they plummeted into negative territory. I computed a Pearson correlation matrix which confirmed a strong negative correlation of -0.22 between Discount and Profit, while Quantity had a negligible impact on margin. This proved that we couldn't simply 'sell our way out' of a high-discount strategy.

**Pause & engage:** Ask if anyone is surprised that higher quantity doesn't always lead to higher profit efficiency.

## Slide 5 — Identifying At-Risk Customers (RFM Analysis)
Beyond products, I analyzed our customer base using Recency, Frequency, and Monetary (RFM) scores calculated in Python. By segmenting the 10,000 rows, I identified a core group of 'At Risk' customers—those who only purchase during extreme 50% discount events and haven't returned in six months. Conversely, our 'VIP' segment showed a willingness to pay full price for specific office supplies. This segmentation allows the marketing team to stop sending deep-discount codes to customers who would have bought the product anyway at a higher margin.

**Pause & engage:** Click to highlight the 'At Risk' segment size compared to the 'VIP' segment.

## Slide 6 — Power BI Dashboard Overview
I consolidated these findings into a Power BI dashboard focused on actionable metrics. The dashboard includes a map visual that highlights states where shipping costs exceed the 15% threshold of total sales. I also included a clustered bar chart comparing Sales versus Profit by Category, which showed that while 'Technology' has high sales, the 'Furniture' category is frequently sold at a loss due to shipping bulk. The scatter plot allows managers to drill down into individual orders to see exactly which transactions are draining the budget.

**Pause & engage:** Mention that the dashboard is interactive and can be filtered by shipping mode or customer segment.

## Slide 7 — AI-Powered Profit Forecasting
To help the regional manager plan for the next quarter, I implemented a Predictive Profit Forecaster using the Power BI Smart Narrative tool and Time-Series Forecasting. By analyzing three years of historical seasonal data, the model predicts a slight recovery in profit margins for the next three months, provided we cap discounts at 20%. The 95% confidence interval shown in the line chart accounts for typical holiday volatility, giving us a realistic upper and lower bound for our recovery targets.

**Pause & engage:** Point out the shaded confidence interval area on the line chart.

## Slide 8 — Strategic Recommendations
Based on this analysis, I have three specific recommendations. First, zenithRetail must implement a hard ceiling on discounts at 25% for the Furniture category, as anything higher leads to a 100% probability of a net loss per order. Second, we should transition the 'At Risk' customer segment to a loyalty-point model rather than direct-discount emails. Finally, we need to renegotiate shipping contracts in the Central region where the shipping cost ratio is 4% higher than the national average.

**Pause & engage:** Invite the stakeholders to view the live dashboard demo.