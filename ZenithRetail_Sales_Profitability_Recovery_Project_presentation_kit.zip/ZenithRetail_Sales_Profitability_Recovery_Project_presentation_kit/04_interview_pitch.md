Context: During my internship at ZenithRetail, a global marketplace, the company faced a critical 12% decline in profit margins. Management was unsure if the cause was marketing spend, shipping costs, or product pricing.

Problem: My objective was to pinpoint exactly where the profit leakage was occurring across 10,000 orders. I needed to determine the 'tipping point' where discounts stopped driving growth and started eroding profit, and how shipping inefficiencies played a role.

Approach: I started by using SQL to run a shipping efficiency audit, calculating delays and costs per shipping mode across different regions. Next, I used Python and Seaborn for Exploratory Data Analysis to map the correlation between discounts and profit. This revealed a sharp profit drop whenever discounts exceeded 30%. To ensure we didn't lose our best customers while cutting costs, I developed an RFM segmentation model to identify 'VIP' versus 'At Risk' segments.

Result: The analysis identified that the 'Tables' and 'Supplies' sub-categories were the primary profit drainers due to high shipping-to-sales ratios. I integrated these findings into a Power BI dashboard with a predictive forecaster. My recommendations—limiting discounts to 30% and renegotiating logistics for high-volume regions—showed a potential for 8% profit recovery.

Learning: This project taught me that high sales volume can be deceptive. I learned how to use Python and SQL in tandem to move from raw data to a business strategy that balances growth with sustainable margins.