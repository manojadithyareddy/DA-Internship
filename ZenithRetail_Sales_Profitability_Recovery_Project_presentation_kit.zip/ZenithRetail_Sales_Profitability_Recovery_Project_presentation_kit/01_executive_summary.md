### Executive Summary: ZenithRetail Profitability Recovery

**Problem**
ZenithRetail experienced a 12% decline in net profit margins during the last fiscal quarter. Initial assessments indicated that high sales volume was being offset by aggressive discounting strategies and rising logistics costs, particularly in the Furniture and Technology sub-categories. There was no existing mechanism to correlate discount depth with actual net margin or to assess the efficiency of different shipping tiers relative to order value.

**Solution**
A data analytics pipeline was developed to audit 10,000 order records. Using SQL window functions, I ranked regional performance and identified specific 'profit-drainer' categories. Python was utilized for Exploratory Data Analysis (EDA) to visualize the negative correlation between discount rates exceeding 30% and net profit. Furthermore, I implemented an RFM (Recency, Frequency, Monetary) segmentation model to identify high-value customers whose profitability was threatened by shipping delays.

**Impact**
The analysis revealed that orders with discounts over 30% contributed to 70% of total losses in the 'Tables' sub-category. By recommending a cap on discount rates and identifying inefficient shipping modes, the project established a roadmap to recover 8% of the lost margin. 

**Tech Stack**
* **Database:** SQL (Window functions, CTEs for regional ranking).
* **Analysis:** Python (Pandas for EDA, Seaborn for visual correlation, Scikit-learn for RFM logic).
* **BI:** Power BI (DAX metrics, Time-Series Forecasting, Smart Narratives).

**Outcome**
The final deliverable is an automated Power BI dashboard that provides real-time visibility into the Shipping Cost Ratio and Return on Sales (ROS). This allows the Regional Manager to adjust pricing and logistics strategies proactively rather than reviewing losses at the end of the quarter.