### Professional Experience: Data Analyst Intern
* Developed a profitability recovery model using a 10k-row dataset, identifying key drivers for a 12% margin decline through SQL (CTEs, Window Functions) and Python (Pandas).
* Engineered an RFM customer segmentation model using Scikit-Learn to categorize 500+ 'At Risk' versus 'VIP' customers based on purchasing frequency and shipping delay impact.
* Built an automated Power BI dashboard featuring predictive time-series forecasting and DAX measures for Net Profit Margin and Shipping Cost Ratio, highlighting $X in potential savings by capping discounts at 30%.
* Conducted statistical correlation analysis in Seaborn to quantify the relationship between discount depth and net loss, resulting in a recommended 8% profit recovery strategy.