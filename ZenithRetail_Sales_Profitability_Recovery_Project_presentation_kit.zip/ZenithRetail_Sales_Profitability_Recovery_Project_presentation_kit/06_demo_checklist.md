[
  "- Open Power BI Desktop and load the 'Executive Summary' tab → Point out the 12% margin decline in the KPI card.",
  "- Navigate to the 'Regional Performance' map → Hover over Texas and Illinois to show negative profit bubbles.",
  "- Switch to the 'Discount Impact' scatter plot → Use the slider to filter for orders with >30% discount to show the cluster of red data points.",
  "- Click on the 'Furniture' category in the bar chart → Observe how the profit margin line dips significantly compared to 'Office Supplies'.",
  "- Open the 'Customer Segments' tab → Show the RFM distribution and highlight the 'At Risk' count.",
  "- Trigger a slicer for 'First Class Shipping' → Show how this shipping mode affects the Net Profit Margin % KPI.",
  "- Navigate to the 'Forecasting' page → Point out the 3-month projected trend line and the Smart Narrative text summary.",
  "- Drill through from a specific unprofitable order to the raw data view → Show the exact OrderID and the Discount-to-Profit ratio.",
  "- Demonstrate the 'What-If' parameter (if applicable) or toggle a filter to show profit if discounts were capped at 20%."
]