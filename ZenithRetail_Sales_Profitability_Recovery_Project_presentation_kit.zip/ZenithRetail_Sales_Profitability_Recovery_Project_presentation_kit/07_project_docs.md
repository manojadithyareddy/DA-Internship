# Project Documentation: ZenithRetail Profitability Recovery

## Overview
This documentation outlines the methodology used to reverse a 12% profit margin decline within the ZenithRetail global marketplace. The project focused on high-discount campaigns and shipping cost escalations as the primary drivers of margin erosion.

## Objectives
1. Isolate product categories/sub-categories yielding negative Return on Sales (ROS).
2. Quantify the impact of discounts exceeding 30% on order-level profitability.
3. Segment the customer base into RFM cohorts to target marketing spend.
4. Predict profit trends for the next business quarter using historical time-series data.

## Scope
- **Data Source**: Kaggle Superstore Dataset (approx. 10k records).
- **Timeframe**: Historical sales data with a 12-month lookback.
- **Geography**: Global regional analysis (North America, EMEA, APAC).

## System Architecture
The solution uses a multi-stage data architecture. Raw order data is staged in a PostgreSQL database where complex joins and aggregations are performed via SQL. Python scripts access the database for statistical exploration and specialized logic (RFM). Cleaned, feature-engineered datasets are then loaded into Power BI for executive reporting.

## Data Model
The data is structured as a star schema within Power BI:
- **Fact Table**: `Order_Metrics` (Sales, Quantity, Discount, Profit, Shipping Cost).
- **Dimension Tables**: `Customers`, `Geography`, `Products`, and a specialized `Date` table to support time-intelligence DAX functions.

## SQL Aggregation Logic
The SQL layer handles raw KPI calculation:
- **Aggregation**: SUM(Sales) vs SUM(Profit) grouping by Sub-Category.
- **Window Functions**: `RANK() OVER (PARTITION BY Region ORDER BY (SUM(Profit)/SUM(Sales)) DESC)` for regional benchmarking.
- **Conditional Logic**: Extracting orders where `Discount > 0.3` to calculate variance between expected and actual margin.

## Python Analysis Workflow
1. **Data Cleaning**: Handled null values in Customer IDs and normalized shipping mode strings.
2. **EDA**: Seaborn scatter plots revealed a non-linear relationship where discounts above 20% lead to logarithmic declines in profit.
3. **RFM Segmentation**:
   - **Recency**: Days since last order.
   - **Frequency**: Total order count per customer.
   - **Monetary**: Total spend per customer.
   - Results were tiered (1-5) and labels like 'Champions' and 'Hibernating' were assigned.

## Power BI Dashboard Spec
- **Executive Summary**: Real-time cards showing current ROS and Shipping Cost Ratio.
- **Profitability Map**: Heat map identifying loss centers by Zip Code.
- **Smart Narrative**: AI-generated summary that highlights the correlation between the 'Technology' category and high shipping costs.
- **Forecaster**: Exponential Smoothing (ETS) algorithm to project 3 months of profitability with a 95% confidence interval.

## Setup and Installation
Pre-requisites: Python 3.10+, PostgreSQL 15, Power BI Desktop.
1. Import `data/raw/superstore.csv` into the `orders` table.
2. Run `notebooks/segmentation.py` to output the `rfm_segments.csv` file.
3. Open the `.pbix` file and map the data sources to the local CSV/PostgreSQL instance.

## Testing and Validation
- **SQL Validation**: Unit tests verifying that `SUM(Profit)` matches the original dataset's control totals.
- **Model Tuning**: RFM bins were validated against existing marketing department segment definitions.
- **Logic Check**: Verified that Return on Sales (ROS) handles zero-sale edge cases to avoid division-by-zero errors.

## Limitations
- The dataset does not include return/refund data, which may skew profitability higher than actual.
- Shipping costs are estimated based on mode and do not account for daily surcharges or fuel price fluctuations.

## Future Scope
- **Automated Refreshes**: Moving the pipeline to Azure Data Factory for daily updates.
- **Churn Prediction**: Using Scikit-learn Logistic Regression to identify customers likely to leave ZenithRetail based on RFM trends.